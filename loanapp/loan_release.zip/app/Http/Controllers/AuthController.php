<?php

namespace App\Http\Controllers;

use App\Enums\UserRole;
use App\Models\User;
use App\Services\AuditService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function register(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email',
            'phone' => 'required|string|max:20|unique:users,phone',
            'password' => 'required|string|min:6',
        ]);

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'phone' => $validated['phone'],
            'password' => Hash::make($validated['password']),
            'role' => UserRole::CUSTOMER,
            'status' => 'active',
        ]);

        $token = $user->createToken('auth_token')->plainTextToken;

        AuditService::log('customer_registered', 'User', $user->id, null, ['email' => $user->email], $user->id);

        return response()->json([
            'success' => true,
            'message' => 'Registration successful',
            'token' => $token,
            'user' => $user,
        ], 201);
    }

    public function login(Request $request): JsonResponse
    {
        $request->validate([
            'login' => 'required|string',
            'password' => 'required|string',
        ]);

        $login = $request->input('login');
        $user = User::where('email', $login)
            ->orWhere('phone', $login)
            ->first();

        if (!$user || !Hash::check($request->input('password'), $user->password)) {
            throw ValidationException::withMessages([
                'login' => ['Invalid email/phone or password.'],
            ]);
        }

        if ($user->status !== 'active') {
            return response()->json([
                'success' => false,
                'message' => 'Your account is suspended. Please contact customer support.',
            ], 403);
        }

        $token = $user->createToken('auth_token')->plainTextToken;

        AuditService::log('user_logged_in', 'User', $user->id, null, null, $user->id);

        return response()->json([
            'success' => true,
            'message' => 'Login successful',
            'token' => $token,
            'user' => $user,
        ]);
    }

    public function me(Request $request): JsonResponse
    {
        $user = $request->user();
        return response()->json([
            'success' => true,
            'user' => $user,
        ]);
    }

    public function updateProfile(Request $request): JsonResponse
    {
        $user = $request->user();

        $validated = $request->validate([
            'name' => 'sometimes|string|max:255',
            'phone' => 'sometimes|string|max:20|unique:users,phone,' . $user->id,
        ]);

        $user->update($validated);

        return response()->json([
            'success' => true,
            'message' => 'Profile updated successfully.',
            'user' => $user,
        ]);
    }

    public function uploadAvatar(Request $request): JsonResponse
    {
        $user = $request->user();

        try {
            if ($request->hasFile('avatar')) {
                $request->validate([
                    'avatar' => 'required|image|mimes:jpeg,png,jpg,webp|max:5120',
                ]);

                $file = $request->file('avatar');
                $fileName = 'avatar_' . $user->id . '_' . time() . '.' . $file->getClientOriginalExtension();
                $path = $file->storeAs('avatars', $fileName, 'public');
                $url = '/storage/' . $path;

                $user->avatar_url = $url;
                $user->save();
            } elseif ($request->filled('avatar_base64')) {
                $base64 = $request->input('avatar_base64');
                
                // Parse and decode data URI if present
                if (preg_match('/^data:image\/(\w+);base64,/', $base64, $matches)) {
                    $imageType = strtolower($matches[1]);
                    if (!in_array($imageType, ['png', 'jpg', 'jpeg', 'webp', 'gif'])) {
                        $imageType = 'png';
                    }
                    $data = substr($base64, strpos($base64, ',') + 1);
                    $decoded = base64_decode($data);
                    
                    if ($decoded !== false) {
                        $fileName = 'avatar_' . $user->id . '_' . time() . '.' . $imageType;
                        \Illuminate\Support\Facades\Storage::disk('public')->put('avatars/' . $fileName, $decoded);
                        $user->avatar_url = '/storage/avatars/' . $fileName;
                        $user->save();
                    } else {
                        $user->avatar_url = $base64;
                        $user->save();
                    }
                } else {
                    $user->avatar_url = $base64;
                    $user->save();
                }
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'No image file or base64 image data provided.',
                ], 422);
            }

            AuditService::log('user_avatar_updated', 'User', $user->id, null, null, $user->id);
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Avatar upload error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Failed to process avatar: ' . $e->getMessage(),
            ], 500);
        }

        return response()->json([
            'success' => true,
            'message' => 'Profile image updated successfully.',
            'user' => $user,
            'avatar_url' => $user->avatar_url,
        ]);
    }

    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'success' => true,
            'message' => 'Successfully logged out.',
        ]);
    }
}
